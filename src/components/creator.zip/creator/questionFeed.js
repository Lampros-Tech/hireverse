function Questionfeed ()
{
    return(
        <>
            <>
                <div className="Content">
                    <div className="">
                        <div className="font-primary text-center py-5 bb-2">
                            Question Feed
                        </div>
                    </div>
                    <div className='Questions my-10'>
                        <div className='card-background uplift h-72 p-2 px-8 rounded-md'>
                            <div className='Tittle font-primary'>
                                Question 1
                            </div>
                            <div className="flex">
                                <div className="font-primary-sm mr-2">
                                    Question Type: 
                                </div>
                                <div className="font-secondary-sm ">
                                    Gener
                                </div>
                            </div>
                            <div className='font-secondary overflow-x-auto description'>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis, ducimus. Nesciunt ullam laudantium odio neque, maxime quaerat vero a voluptatibus ratione quidem quo dignissimos dolor libero vitae iusto odit facilis.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis, ducimus. Nesciunt ullam laudantium odio neque, maxime quaerat vero a voluptatibus ratione quidem quo dignissimos dolor libero vitae iusto odit facilis.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis, ducimus. Nesciunt ullam laudantium odio neque, maxime quaerat vero a voluptatibus ratione quidem quo dignissimos dolor libero vitae iusto odit facilis.
                            </div>
                            <div className='text-center w-full'>
                                <button className='Edit-Question p-3 rounded-md mt-7'>
                                    Add to repository.
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </>
        </>
    )
}
export default Questionfeed;