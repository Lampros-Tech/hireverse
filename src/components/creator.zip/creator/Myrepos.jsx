import "./Myrepos.css"
function Myrepos ()
{
    return(
        <>
            <div className="parent-content">
                    <div className="M-Content min-h-screen px-0.5 py-10">
                        <div className="font-primary text-center py-5 bb-2">
                            My Repositories
                        </div>
                        <div className="card uplift my-8 p-2 rounded-md">
                            <div className="font-secondary font-semibold text-2xl p-1">
                                Name of repository
                            </div>
                            <div className="flex my-2">
                                <div className="font-primary-sm ml-1 mr-1">
                                        Created on:
                                </div>
                                <div className="font-secondary-sm">
                                        Date:time
                                </div>
                            </div>
                            <div className="p-1">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime molestias dolorem impedit fuga libero, doloribus vitae possimus ipsum nostrum iste perferendis? Accusamus maiores, modi atque ipsum ea exercitationem neque quasi!.
                            </div>
                            <div className="p-4 text-center">
                                <button className="create-assessment-btn p-4 rounded">
                                    View Reopository
                                </button>
                            </div>
                        </div>
                       

                        <div className="card uplift my-8 p-2 rounded-md">
                            <div className="font-secondary font-semibold text-2xl p-1">
                                Name of repository
                            </div>
                            <div className="flex my-2">
                                <div className="font-primary-sm ml-1 mr-1">
                                        Created on:
                                </div>
                                <div className="font-secondary-sm">
                                        Date:time
                                </div>
                            </div>
                            <div className="p-1">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime molestias dolorem impedit fuga libero, doloribus vitae possimus ipsum nostrum iste perferendis? Accusamus maiores, modi atque ipsum ea exercitationem neque quasi!.
                            </div>
                            <div className="p-4 text-center">
                                <button className="create-assessment-btn p-4 rounded">
                                    View Reopository
                                </button>
                            </div>
                        </div>


                        <div className="card uplift my-8 p-4 rounded-md">
                            <div className="font-secondary font-semibold text-2xl p-1">
                                Name of repository
                            </div>
                            <div className="flex my-2">
                                <div className="font-primary-sm ml-1 mr-1">
                                        Created on:
                                </div>
                                <div className="font-secondary-sm">
                                        Date:time
                                </div>
                            </div>
                            <div className="p-1">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime molestias dolorem impedit fuga libero, doloribus vitae possimus ipsum nostrum iste perferendis? Accusamus maiores, modi atque ipsum ea exercitationem neque quasi!.
                            </div>
                            <div className="p-4 text-center">
                                <button className="create-assessment-btn p-4 rounded">
                                    View Reopository
                                </button>
                            </div>
                            
                        </div>
                    </div>
            </div>
        </>
    )
}
export default Myrepos;